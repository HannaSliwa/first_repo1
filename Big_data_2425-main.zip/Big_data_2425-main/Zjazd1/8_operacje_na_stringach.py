slowo = 'mama'
napis = 'PieS piesek pieseczek'

print(slowo.replace('a', 'A', 1))
nowy_napis = napis.split()
print('napis ma', len(nowy_napis), 'słów')
print(napis.lower())


