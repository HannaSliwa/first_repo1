for i in range(4, 8):    #od do
    print(i)

for i in range(0, 18, 3):    #od, do, krok
    print(i)

for i in range(99, 5, -17):    #od, do, krok
    print(i)