print(10 * 1.1)
print(10 * 10)
print(10 * 1.1 * 10)
print(10 * 10 * 1.1)


def mnozenie(a, b):
    return round(a * b, 5)

print(mnozenie(100, 1.1))