print('Costam')
print('ghfdf')
print('cos')

# tutaj losowe rzeczy, aby zobaczyc git pull i konflikt

