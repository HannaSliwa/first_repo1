# zakupy = ['chleb', 'mleko', 'platki', 'platki']
uzytkownicy = ['Kamil', 'Python123', 'Monia', 'Monia1', 'Monia']
hasla =       ['123',    'asfaf3f',   'Piesek', '1234', 'dsdf']

users = {
    'Kamil': '1234',
    'Python': 'asfaf3f',
    'Monia': 'Piesek',
    'Monia1': '1234'
}

print(users)
# print(users[2])
print(users['Kamil'])
users['Mariusz'] = '4356'   # dodaj
users['Monia'] = 'Kotek'    # nadpisz
print(users)

