do_kupienia = ['machew', 'chleb', 'maslo', 'mleko']

for i in range(5):
    print(i)

for i in range(len(do_kupienia)):
    print(do_kupienia[i])

for produkt in do_kupienia:
    print(produkt)